"use client";

import { useState } from "react";
import { PageTabs } from "@/components/page-tabs";
import { Button } from "@/components/ui/button";
import { loadBatches, type StudentRow } from "@/lib/analysis";
import type { Assessment } from "@/lib/assessment-data";
import { assessmentKey, compareHomeworkAge } from "@/lib/ranking";

type Sort = "high" | "low" | "name";

export default function ScoresPage() {
  const [rows, setRows] = useState<StudentRow[] | null>(null);
  const [selected, setSelected] = useState("");
  const [sort, setSort] = useState<Sort>("high");
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [unavailable, setUnavailable] = useState(0);
  const [error, setError] = useState("");

  async function load() {
    setLoading(true); setError(""); setProgress({ done: 0, total: 0 });
    try {
      const data = await loadBatches("list", (done, total) => setProgress({ done, total }));
      setRows(data.rows); setUnavailable(data.unavailable);
      const available = data.rows.flatMap((row) => row.items ?? []);
      const first = available.find((item) => item.score !== null) ?? available[0];
      setSelected((previous) => available.some((item) => assessmentKey(item) === previous) ? previous : first ? assessmentKey(first) : "");
    } catch (reason) { setError(reason instanceof Error ? reason.message : "성적을 불러오지 못했습니다."); }
    finally { setLoading(false); }
  }

  const catalog = new Map<string, Assessment>();
  for (const row of rows ?? []) for (const item of row.items ?? []) {
    const key = assessmentKey(item);
    if (!catalog.has(key)) catalog.set(key, item);
  }
  const tasks = [...catalog.entries()].sort((a, b) => {
    if (a[1].kind !== b[1].kind) return a[1].kind === "hw" ? -1 : 1;
    return compareHomeworkAge(a[1], b[1]);
  });
  const roster = (rows ?? []).flatMap((row) => {
    const item = row.items?.find((candidate) => assessmentKey(candidate) === selected);
    return item ? [{ name: row.name, id: row.id, item }] : [];
  }).sort((a, b) => {
    if (sort === "name") return a.name.localeCompare(b.name, "ko") || a.id.localeCompare(b.id);
    if (a.item.score === null) return b.item.score === null ? a.name.localeCompare(b.name, "ko") : 1;
    if (b.item.score === null) return -1;
    return (sort === "high" ? b.item.score - a.item.score : a.item.score - b.item.score) || a.name.localeCompare(b.name, "ko");
  });
  const submitted = roster.filter((row) => !!row.item.submitted_at).length;

  return <>
    <header className="site-header"><div className="container"><h1>전체 성적</h1></div></header>
    <main className="container main-content">
      <PageTabs active="scores" />
      <section className="search-panel">
        <h2>숙제·시험별 성적</h2>
        <p>학생별 점수 목록을 불러옵니다.</p>
        <Button type="button" onClick={load} disabled={loading}>{loading ? "확인 중…" : rows ? "새로 조회" : "전체 성적 조회"}</Button>
        {error && <p className="error" role="alert">{error}</p>}
      </section>
      {loading && <div className="initial-empty" role="status">{progress.total ? `${progress.total}명 중 ${progress.done}명 확인 중…` : "성적 목록을 확인하는 중…"}</div>}
      {rows && <section className="group">
        <div className="roster-controls">
          <label>과제 선택<select value={selected} onChange={(event) => setSelected(event.target.value)}>
            {tasks.map(([key, item]) => <option value={key} key={key}>{item.kind === "hw" ? "숙제" : "시험"} · {item.title}</option>)}
          </select></label>
          <label>정렬<select value={sort} onChange={(event) => setSort(event.target.value as Sort)}>
            <option value="high">성적 내림차순</option><option value="low">성적 오름차순</option><option value="name">가나다순</option>
          </select></label>
        </div>
        {unavailable > 0 && <p className="ranking-warning">{unavailable}명 목록을 확인하지 못했습니다. 조회된 학생 기준입니다.</p>}
        {selected ? <>
          <div className="roster-summary"><strong>{catalog.get(selected)?.title}</strong><span>제출 {submitted}/{roster.length}명 · 채점 {roster.filter((row) => row.item.score !== null).length}명</span></div>
          <div className="roster-table-wrap"><table className="roster-table"><thead><tr><th scope="col">학생</th><th scope="col">점수</th><th scope="col">상태</th></tr></thead>
            <tbody>{roster.map((row) => <tr key={row.id}><td>{row.name}</td><td className="roster-score">{row.item.score === null ? "—" : `${row.item.score}점`}</td><td>{row.item.submitted_at ? row.item.score === null ? "채점 전" : "채점 완료" : "미제출"}</td></tr>)}</tbody>
          </table></div>
          {!roster.length && <div className="empty-card">해당 과제의 학생 기록이 없습니다.</div>}
        </> : <div className="initial-empty">조회된 과제가 없습니다.</div>}
      </section>}
    </main>
  </>;
}
